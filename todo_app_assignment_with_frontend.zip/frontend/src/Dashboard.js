import axios from 'axios';
import { useEffect, useState } from 'react';

export default function Dashboard() {
  const [todos, setTodos] = useState([]);
  const [title, setTitle] = useState('');
  const [desc, setDesc] = useState('');

  const getTodos = async () => {
    const res = await axios.get('http://localhost:5000/todo', {
      headers: { Authorization: \`Bearer \${localStorage.getItem('token')}\` },
    });
    setTodos(res.data);
  };

  const createTodo = async () => {
    await axios.post(
      'http://localhost:5000/todo',
      { title, description: desc },
      { headers: { Authorization: \`Bearer \${localStorage.getItem('token')}\` } }
    );
    getTodos();
  };

  const deleteTodo = async id => {
    await axios.delete(\`http://localhost:5000/todo/\${id}\`, {
      headers: { Authorization: \`Bearer \${localStorage.getItem('token')}\` },
    });
    getTodos();
  };

  useEffect(() => {
    getTodos();
  }, []);

  return (
    <div>
      <h2>Todos</h2>
      <input placeholder="title" onChange={e => setTitle(e.target.value)} />
      <input placeholder="desc" onChange={e => setDesc(e.target.value)} />
      <button onClick={createTodo}>Add Todo</button>
      <ul>
        {todos.map(todo => (
          <li key={todo.id}>
            {todo.title} <button onClick={() => deleteTodo(todo.id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}