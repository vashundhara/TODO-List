from app import app, db, jwt, mail
from flask import request, jsonify
from models import User, Todo
from flask_bcrypt import Bcrypt
from flask_jwt_extended import create_access_token, jwt_required, get_jwt_identity
from flask_mail import Message

bcrypt = Bcrypt(app)

@app.route('/register', methods=['POST'])
def register():
    data = request.json
    hashed = bcrypt.generate_password_hash(data['password']).decode('utf-8')
    user = User(email=data['email'], password=hashed)
    db.session.add(user)
    db.session.commit()
    return jsonify({'message': 'User created'})

@app.route('/login', methods=['POST'])
def login():
    data = request.json
    user = User.query.filter_by(email=data['email']).first()
    if user and bcrypt.check_password_hash(user.password, data['password']):
        token = create_access_token(identity=user.id)
        return jsonify({'token': token})
    return jsonify({'error': 'Invalid credentials'}), 401

@app.route('/todo', methods=['POST'])
@jwt_required()
def create_todo():
    user_id = get_jwt_identity()
    data = request.json
    todo = Todo(title=data['title'], description=data['description'], user_id=user_id)
    db.session.add(todo)
    db.session.commit()

    user = User.query.get(user_id)
    msg = Message('New Todo Created', recipients=[user.email], body=f"Todo '{todo.title}' created.")
    mail.send(msg)

    return jsonify({'message': 'Todo created'})

@app.route('/todo', methods=['GET'])
@jwt_required()
def get_todos():
    user_id = get_jwt_identity()
    todos = Todo.query.filter_by(user_id=user_id).all()
    return jsonify([{'id': t.id, 'title': t.title, 'description': t.description} for t in todos])

@app.route('/todo/<int:id>', methods=['DELETE'])
@jwt_required()
def delete_todo(id):
    user_id = get_jwt_identity()
    todo = Todo.query.get(id)
    if todo and todo.user_id == user_id:
        db.session.delete(todo)
        db.session.commit()
        return jsonify({'message': 'Deleted'})
    return jsonify({'error': 'Unauthorized or not found'}), 403